LARA (Clone of ZARA)

LARA is a Online Clothes shopping website. It have Clothes for Both Men & Women.User can buy clothes here like Zara & Mynthra.Its suitable for real world application.

 			It contain Registration page & Login page (Backend By PHP & SQL). user need to Register with details and Login with Valid Username & Password. It is directly Redirected to Home page.That page contain Navbar with page links, Banner section, product section (by Cards), product images(with Carousel), footer section (with Pagination). It also has Many pages like
About Page, product Page, Contact Page. For Frontend I was use HTML,CSS,JavaScript,BootStrap.
