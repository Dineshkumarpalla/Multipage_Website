<?php
    $fullname=$_POST['fullname'];
    $username=$_POST['username'];
    $pwd=$_POST['pwd'];
    $conn=mysqli_connect('localhost','root','','sai');
    $sql="INSERT INTO signup VALUES('$fullname','$username','$pwd');";
    if (mysqli_query($conn,$sql)){
        if (mkdir($fullname)){
            header('Location:index.html');
        }
    }
    else{
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
?>
