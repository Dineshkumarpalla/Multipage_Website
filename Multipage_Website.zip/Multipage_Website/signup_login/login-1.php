<html>
    <body>
        <?php
            session_start();
            $username=$_POST['username'];
            $pwd=$_POST['pwd'];		
            $conn=mysqli_connect('localhost','root','','sai');
            $sql="SELECT * FROM signup WHERE username='$username' AND password='$pwd';";
            $res=mysqli_query($conn,$sql);
            $no_of_rows=mysqli_num_rows($res);
            if ($no_of_rows>0){
                while ($row=mysqli_fetch_assoc($res)){
                    $_SESSION['name']=$row['fullname'];
                }
                header('Location:../ecommerce/index1.html');
                
            }
            else{
                header('Location:alert.html');
                
            }
        ?>
    </body>
</html>
