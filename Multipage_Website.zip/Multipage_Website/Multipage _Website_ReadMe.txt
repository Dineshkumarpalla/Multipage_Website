Multipage Website

	It is a Online Website For Buying Fruits and Vegitables. user need to Signup with details & Login with already given Username and Password. Other it notify Create Account With details on Signup page. 
	 
	 It Create a Login Table with Username & Password in Database (Backend By PHP & SQL). It is directly Redirected to Home page.That page contain Navbar with page links, Banner section, product section (by Cards), product images(with Carousel), footer section (with Pagination). It also has Many pages like
About Page, product Page, Contact Page. For Frontend I was use HTML,CSS,JavaScript,BootStrap.
